
from Model import Model

model = Model(r'.\data\2024-2025_ПІ_Бакалаври.xlsx', (10, 1))

# for st in model.students:
#     print(st)


# for t in model.teams:
#     print(t)

# for s in model.slots:
#     print(s)

